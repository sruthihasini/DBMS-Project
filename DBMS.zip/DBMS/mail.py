import smtplib

def email(recv, reg, pswd):
    sender = 'sumanjali313@outlook.com'
    receivers = recv
    message = """
    Subject: Registration Details
    Registration Id:"""+str(reg)+"""
    Password:"""+pswd+"""
    """
    smtp = smtplib.SMTP("smtp.office365.com",587)
    smtp.starttls()
    smtp.login('sumanjali313@outlook.com', 'sumanjali@313')
    smtp.sendmail(sender, receivers, message)
