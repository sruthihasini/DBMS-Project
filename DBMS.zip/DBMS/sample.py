import sqlite3
con = sqlite3.connect("GAT.db")
con.execute("SELECT regid,password FROM student")
cursor_obj = con.cursor()
cursor_obj.execute("SELECT regid,password FROM student")
data = cursor_obj.fetchall()
list_data = []
data_dict = dict()
for i in data:
    list_data.append(list(i))
for i in list_data:
    data_dict[i[0]] = i[1]
for i in  list_data:
    print(i)
